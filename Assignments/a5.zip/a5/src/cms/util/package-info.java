/** Utilities originally developed for the CMS (CMSX) project.
 */
package cms.util;

