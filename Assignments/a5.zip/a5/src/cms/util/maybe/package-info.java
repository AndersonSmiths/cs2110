/**
 * Support for the type {@code Maybe<T>}
 */
package cms.util.maybe;

