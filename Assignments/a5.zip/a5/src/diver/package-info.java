/** The place for your diver algorithm.
 */
package diver;

